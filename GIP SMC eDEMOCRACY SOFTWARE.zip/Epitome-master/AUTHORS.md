## Authors

Epitome is a collaborative effort.

The Core Epitome team:

* Georgios Mavropalias
* Panagiotis Tokmakidis
* Pavlos Boudagidis

With input and contributions from (in chronological order):


Thank you!
